<?php

// Add user
if (isset($_POST['add_user']) && isAdmin()) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];

    $conn->query("INSERT INTO users (name, email, password, role) VALUES ('$name','$email','$password','$role')");
}

// Delete user
if (isset($_GET['delete_user']) && isAdmin()) {
    $id = $_GET['delete_user'];
    $conn->query("DELETE FROM users WHERE id=$id");
}

?>