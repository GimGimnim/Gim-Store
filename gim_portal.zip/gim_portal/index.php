<!DOCTYPE html>
<html>
<head>
    <title>Gim University Portal</title>
</head>
<body>

<h1>Welcome to Gim University</h1>

<?php if (!isLoggedIn()): ?>
<form method="POST">
    <input type="email" name="email" placeholder="Email" required><br>
    <input type="password" name="password" placeholder="Password" required><br>
    <button name="login">Login</button>
</form>
<?php else: ?>
<a href="?logout=true">Logout</a>
<?php endif; ?>

<?php if (isLoggedIn()): ?>

<h2>User Dashboard</h2>

<form method="POST" enctype="multipart/form-data">
    <input type="file" name="file" required>
    <button name="upload">Upload</button>
</form>

<h3>Your Files</h3>
<ul>
<?php
$user_id = $_SESSION['user_id'];
$result = $conn->query("SELECT * FROM files WHERE user_id=$user_id");
while ($row = $result->fetch_assoc()) {
    echo "<li>{$row['file_name']} <a href='?delete_file={$row['id']}'>Delete</a></li>";
}
?>
</ul>

<?php if (isAdmin()): ?>

<h2>Admin Dashboard</h2>

<h3>Add User</h3>
<form method="POST">
    <input name="name" placeholder="Name" required>
    <input name="email" placeholder="Email" required>
    <input name="password" type="password" required>
    <select name="role">
        <option value="user">User</option>
        <option value="admin">Admin</option>
    </select>
    <button name="add_user">Add</button>
</form>

<h3>All Users</h3>
<ul>
<?php
$res = $conn->query("SELECT * FROM users");
while ($u = $res->fetch_assoc()) {
    echo "<li>{$u['name']} ({$u['role']}) <a href='?delete_user={$u['id']}'>Delete</a></li>";
}
?>
</ul>

<?php endif; ?>

<?php endif; ?>

</body>
</html>
