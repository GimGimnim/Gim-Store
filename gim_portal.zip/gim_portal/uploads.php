<?php

if (isset($_POST['upload'])) {
    if (!isLoggedIn()) die("Unauthorized");

    $fileName = $_FILES['file']['name'];
    $tmpName  = $_FILES['file']['tmp_name'];
    $path = "uploads/" . basename($fileName);

    move_uploaded_file($tmpName, $path);

    $user_id = $_SESSION['user_id'];
    $sql = "INSERT INTO files (user_id, file_name, file_path) VALUES ('$user_id', '$fileName', '$path')";
    $conn->query($sql);
}

// Delete File
if (isset($_GET['delete_file'])) {
    $id = $_GET['delete_file'];
    $conn->query("DELETE FROM files WHERE id=$id");
}

?>